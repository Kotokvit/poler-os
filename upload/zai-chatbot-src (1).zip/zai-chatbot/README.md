# Z.ai Чат-бот — Next.js + z-ai-web-dev-sdk

Веб-чат на русском языке, который обращается к Z.ai LLM (модели GLM) через
`z-ai-web-dev-sdk`. Использует встроенный псевдо-API ключ окружения —
без отдельной настройки `ZAI_API_KEY`.

## Стек

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS 4 + shadcn/ui (New York)
- `z-ai-web-dev-sdk` (backend only)
- `react-markdown` + `react-syntax-highlighter` для рендера Markdown и кода
- `framer-motion` для анимаций
- `lucide-react` для иконок
- История чата и системный промпт сохраняются в `localStorage`

## Запуск локально

```bash
# 1. Установить зависимости (нужен Node 18+ и bun или npm)
bun install
# или: npm install

# 2. Запустить dev-сервер
bun run dev
# или: npm run dev

# 3. Открыть http://localhost:3000
```

## Структура

```
src/
├─ app/
│  ├─ api/chat/route.ts   # POST /api/chat — прокси к z-ai-web-dev-sdk
│  ├─ layout.tsx          # root layout (lang="ru")
│  ├─ page.tsx            # UI чата
│  └─ globals.css         # Tailwind + тема
├─ components/ui/         # shadcn/ui компоненты
├─ hooks/                 # хуки (use-toast, use-mobile)
└─ lib/                   # утилиты и db-клиент Prisma
```

## API

`POST /api/chat`

```jsonc
// Запрос
{
  "messages": [{ "role": "user", "content": "Привет!" }],
  "systemPrompt": "Необязательный системный промпт",
  "thinking": false          // true включает chain-of-thought
}

// Ответ
{
  "success": true,
  "content": "Ответ модели",
  "usage": { "completion_tokens": 22, "prompt_tokens": 78, "total_tokens": 100 }
}
```

## Что можно доработать

- Реальный стриминг через `ReadableStream` (сейчас — typewriter-эффект)
- Мульти-диалоги в боковой панели
- Поддержка изображений (VLM)
- Аутентификация (NextAuth.js уже в зависимостях)
- Хранение истории в SQLite через Prisma (схема уже настроена)

## Подключение собственного ZAI_API_KEY (опционально)

По умолчанию в sandbox используется встроенный псевдо-ключ окружения, который
работает **только** через `z-ai-web-dev-sdk`. Для локального запуска:

1. Получите API-ключ в консоли Z.AI: https://z.ai/
2. Создайте файл `.env` в корне проекта:
   ```
   ZAI_API_KEY=sk-...
   ```
3. Перезапустите `bun run dev`.

SDK автоматически подхватит переменную.

## Альтернатива: использовать OpenClaw вместо Next.js

OpenClaw — это self-hosted AI-агент gateway (открытый код, github.com/openclaw/openclaw),
который поддерживает Z.ai (модели GLM) и **множество других провайдеров**.
Установка:

```bash
# macOS / Linux / WSL2
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --no-onboard
```

### Вариант A — с настоящим ключом (прямой доступ к Z.ai API)

```bash
openclaw plugins install @openclaw/zai-provider
openclaw onboard --auth-choice zai-api-key
# или явно выбрать регион:
#   zai-global          -> https://api.z.ai/api/paas/v4        (glm-5.1)
#   zai-cn              -> https://open.bigmodel.cn/api/paas/v4 (glm-5.1)
#   zai-coding-global   -> https://api.z.ai/api/coding/paas/v4  (glm-5.2)
#   zai-coding-cn       -> https://open.bigmodel.cn/api/coding/paas/v4 (glm-5.2)

openclaw models list --all --provider zai
openclaw agent --local --model zai/glm-5.2 --message "Привет"
```

### Вариант B — БЕЗ ключа, через встроенный псевдо-ключ и локальный прокси

В этом репозитории уже реализован **OpenAI-compatible endpoint** на тех же
маршрутах Next.js:

```
GET  /api/v1/models            — список моделей
POST /api/v1/chat/completions  — OpenAI Chat Completions (stream + non-stream)
```

Эти маршруты **игнорируют Authorization header** — любой apiKey принимается.
Внутри они вызывают `z-ai-web-dev-sdk` через встроенный псевдо-API ключ sandbox,
то есть **настоящий `ZAI_API_KEY` не нужен**.

Подключение к OpenClaw (после установки):

```bash
# 1. Прописать в ~/.openclaw/openclaw.json провайдер zaibridge:
cat > ~/.openclaw/openclaw.json << 'CFG'
{
  "plugins": { "allow": [] },
  "models": {
    "mode": "merge",
    "providers": {
      "zaibridge": {
        "baseUrl": "http://127.0.0.1:3000/api/v1",
        "apiKey": "pseudo-key",
        "api": "openai-completions",
        "timeoutSeconds": 300,
        "models": [
          { "id": "glm-5",   "name": "GLM-5 via zai-bridge",   "contextWindow": 200000,  "maxTokens": 8192, "input": ["text"] },
          { "id": "glm-5.2", "name": "GLM-5.2 via zai-bridge", "contextWindow": 1000000, "maxTokens": 8192, "input": ["text"] },
          { "id": "glm-5.1", "name": "GLM-5.1 via zai-bridge", "contextWindow": 200000,  "maxTokens": 8192, "input": ["text"] },
          { "id": "glm-4.7", "name": "GLM-4.7 via zai-bridge", "contextWindow": 200000,  "maxTokens": 8192, "input": ["text"] }
        ]
      }
    }
  },
  "agents": { "defaults": { "model": { "primary": "zaibridge/glm-5" } } }
}
CFG

# 2. Проверить конфиг
openclaw config validate

# 3. Запустить Next.js (этот проект) на http://127.0.0.1:3000
bun run dev

# 4. В отдельном терминале — вызвать агента
openclaw models list --all --provider zaibridge
openclaw agent --local --model zaibridge/glm-5.2 --message "Привет!"
```

OpenClaw будет слать запросы на `http://127.0.0.1:3000/api/v1/chat/completions`,
а наш backend под капотом вызовет `z-ai-web-dev-sdk` с встроенным псевдо-ключом.
**Никакого `ZAI_API_KEY` в env или конфиге не требуется** — apiKey `"pseudo-key"`
в конфиге нужен только для удовлетворения схемы OpenClaw и фактически не проверяется.
