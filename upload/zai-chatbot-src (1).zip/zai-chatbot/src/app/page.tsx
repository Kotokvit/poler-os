'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Toaster } from '@/components/ui/toaster'
import { useToast } from '@/hooks/use-toast'
import {
  Send,
  Trash2,
  SquareUser,
  Sparkles,
  Loader2,
  Settings2,
  Copy,
  Check,
} from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'

type Role = 'user' | 'assistant'
interface ChatMessage {
  id: string
  role: Role
  content: string
}

const STORAGE_KEY = 'zai-chat-history-v1'

const STARTER_MESSAGES: ChatMessage[] = [
  {
    id: 'starter',
    role: 'assistant',
    content:
      'Привет! Я чат-бот на **Next.js**, подключённый к **Z.ai LLM** через встроенный псевдо-API ключ окружения.\n\nМожешь спросить меня что угодно — я поддерживаю Markdown, блоки кода и контекст диалога.',
  },
]

function loadHistory(): ChatMessage[] {
  if (typeof window === 'undefined') return STARTER_MESSAGES
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return STARTER_MESSAGES
    const parsed = JSON.parse(raw) as ChatMessage[]
    if (!Array.isArray(parsed) || parsed.length === 0) return STARTER_MESSAGES
    return parsed
  } catch {
    return STARTER_MESSAGES
  }
}

function saveHistory(messages: ChatMessage[]) {
  if (typeof window === 'undefined') return
  try {
    // Не храним «стартер» отдельно — он уже в массиве
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages))
  } catch {
    /* ignore */
  }
}

function uid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>(STARTER_MESSAGES)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [thinking, setThinking] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [systemPrompt, setSystemPrompt] = useState('')
  const [hydrated, setHydrated] = useState(false)
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const taRef = useRef<HTMLTextAreaElement | null>(null)
  const { toast } = useToast()

  // Hydrate from localStorage
  useEffect(() => {
    setMessages(loadHistory())
    try {
      const sp = window.localStorage.getItem('zai-chat-system-prompt')
      if (sp) setSystemPrompt(sp)
    } catch {}
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (hydrated) saveHistory(messages)
  }, [messages, hydrated])

  useEffect(() => {
    if (hydrated) {
      try {
        window.localStorage.setItem('zai-chat-system-prompt', systemPrompt)
      } catch {}
    }
  }, [systemPrompt, hydrated])

  // Autoscroll to bottom
  useEffect(() => {
    const el = scrollRef.current
    if (el) {
      el.scrollTop = el.scrollHeight
    }
  }, [messages, loading])

  const send = useCallback(async () => {
    const text = input.trim()
    if (!text || loading) return

    const userMsg: ChatMessage = { id: uid(), role: 'user', content: text }
    const placeholder: ChatMessage = {
      id: uid(),
      role: 'assistant',
      content: '',
    }

    const nextHistory = [...messages.filter((m) => m.id !== 'starter'), userMsg]
    setMessages([...nextHistory, placeholder])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextHistory.map((m) => ({ role: m.role, content: m.content })),
          systemPrompt: systemPrompt.trim() || undefined,
          thinking,
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.success) {
        throw new Error(data?.error || `HTTP ${res.status}`)
      }
      // Типографский эффект печати
      await typewrite(data.content as string, (partial) => {
        setMessages((cur) =>
          cur.map((m) => (m.id === placeholder.id ? { ...m, content: partial } : m))
        )
      })
    } catch (e) {
      const err = e instanceof Error ? e.message : String(e)
      setMessages((cur) =>
        cur.map((m) =>
          m.id === placeholder.id
            ? { ...m, content: `⚠️ **Ошибка запроса:** ${err}` }
            : m
        )
      )
      toast({
        title: 'Не удалось получить ответ',
        description: err,
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }, [input, loading, messages, systemPrompt, thinking, toast])

  const typewrite = async (full: string, set: (s: string) => void) => {
    // Если ответ длинный — печатаем чанками, иначе почти мгновенно
    const chunkSize = Math.max(2, Math.floor(full.length / 80))
    let i = 0
    while (i < full.length) {
      i = Math.min(full.length, i + chunkSize)
      set(full.slice(0, i))
      // небольшой sleep, чтобы глаз успевал
      await new Promise((r) => setTimeout(r, 12))
    }
    set(full)
  }

  const clearChat = () => {
    setMessages(STARTER_MESSAGES)
    toast({ title: 'Чат очищен', description: 'История сброшена.' })
  }

  const copyMessage = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({ title: 'Скопировано', description: 'Текст сообщения в буфере.' })
    } catch {
      toast({
        title: 'Не удалось скопировать',
        variant: 'destructive',
      })
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-20">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-semibold leading-tight truncate">
                Z.ai Чат-бот
              </h1>
              <p className="text-xs text-muted-foreground truncate">
                Подключение через встроенный API-ключ окружения
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings((v) => !v)}
              aria-label="Настройки"
            >
              <Settings2 className="h-4 w-4" />
              <span className="hidden sm:inline ml-1.5">Настройки</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearChat}
              aria-label="Очистить чат"
            >
              <Trash2 className="h-4 w-4" />
              <span className="hidden sm:inline ml-1.5">Очистить</span>
            </Button>
          </div>
        </div>

        {/* Settings panel */}
        <AnimatePresence initial={false}>
          {showSettings && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t bg-muted/30"
            >
              <div className="max-w-4xl mx-auto px-4 py-4 space-y-4">
                <div>
                  <Label htmlFor="system-prompt" className="text-xs font-medium">
                    Системный промпт (по умолчанию — «ассистент на русском»)
                  </Label>
                  <Textarea
                    id="system-prompt"
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    placeholder="Например: Ты — Junior-разработчик, объясняй простыми словами и давай короткие ответы."
                    className="mt-1.5 min-h-[70px] text-sm resize-y"
                  />
                  <p className="text-[11px] text-muted-foreground mt-1">
                    Применится к следующему сообщению. История сохраняется в
                    localStorage браузера.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Switch
                    id="thinking"
                    checked={thinking}
                    onCheckedChange={setThinking}
                  />
                  <Label htmlFor="thinking" className="text-sm cursor-pointer">
                    Включить режим размышления (chain-of-thought)
                  </Label>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Chat area */}
      <main className="flex-1 w-full">
        <div className="max-w-4xl mx-auto px-4 py-6 h-[calc(100vh-160px)]">
          <div
            ref={scrollRef}
            className="h-full overflow-y-auto pr-1 space-y-4 scroll-smooth"
            style={{
              scrollbarWidth: 'thin',
            }}
          >
            {messages.map((m) => (
              <MessageBubble
                key={m.id}
                message={m}
                loading={loading && m.role === 'assistant' && !m.content}
                onCopy={() => copyMessage(m.content)}
              />
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground pl-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>Модель думает…</span>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Input */}
      <footer className="border-t bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky bottom-0">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-end gap-2 rounded-2xl border bg-background p-2 shadow-sm focus-within:ring-2 focus-within:ring-ring/40 transition">
            <Textarea
              ref={taRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Напишите сообщение… (Enter — отправить, Shift+Enter — перенос строки)"
              disabled={loading}
              className="flex-1 resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[44px] max-h-[200px] text-sm"
              rows={1}
              style={{
                height: 'auto',
              }}
              onInput={(e) => {
                const t = e.currentTarget
                t.style.height = 'auto'
                t.style.height = Math.min(200, t.scrollHeight) + 'px'
              }}
            />
            <Button
              onClick={send}
              disabled={!input.trim() || loading}
              size="icon"
              className="rounded-xl h-10 w-10 shrink-0"
              aria-label="Отправить"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
          <p className="text-[11px] text-muted-foreground mt-1.5 px-1">
            Чат обращается к Z.ai LLM через встроенный ключ окружения.
            Автономно работает без настройки.
          </p>
        </div>
      </footer>

      <Toaster />
    </div>
  )
}

/* ---------- Message bubble ---------- */

function MessageBubble({
  message,
  loading,
  onCopy,
}: {
  message: ChatMessage
  loading?: boolean
  onCopy: () => void
}) {
  const isUser = message.role === 'user'
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
    onCopy()
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.18 }}
      className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      {!isUser && (
        <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles className="h-4 w-4 text-primary" />
        </div>
      )}

      <div
        className={`group max-w-[85%] sm:max-w-[75%] ${
          isUser
            ? 'bg-primary text-primary-foreground rounded-2xl rounded-tr-sm'
            : 'bg-card border rounded-2xl rounded-tl-sm'
        } px-4 py-2.5 shadow-sm`}
      >
        {loading ? (
          <div className="flex items-center gap-1.5 py-1">
            <span className="h-2 w-2 rounded-full bg-current opacity-60 animate-bounce [animation-delay:-0.3s]" />
            <span className="h-2 w-2 rounded-full bg-current opacity-60 animate-bounce [animation-delay:-0.15s]" />
            <span className="h-2 w-2 rounded-full bg-current opacity-60 animate-bounce" />
          </div>
        ) : isUser ? (
          <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">
            {message.content}
          </p>
        ) : (
          <div className="text-sm leading-relaxed prose prose-sm dark:prose-invert max-w-none break-words [&_pre]:my-2 [&_pre]:rounded-lg [&_code]:rounded [&_code]:px-1 [&_code]:py-0.5 [&_code]:bg-muted [&_code]:text-foreground">
            <ReactMarkdown
              components={{
                code({ node, className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || '')
                  const isInline = !match && !String(children).includes('\n')
                  if (isInline) {
                    return (
                      <code className={className} {...props}>
                        {children}
                      </code>
                    )
                  }
                  return (
                    <SyntaxHighlighter
                      // @ts-expect-error - style typing mismatch
                      style={oneDark}
                      language={match?.[1] || 'text'}
                      PreTag="div"
                      customStyle={{
                        margin: 0,
                        background: 'transparent',
                        fontSize: '0.8rem',
                      }}
                    >
                      {String(children).replace(/\n$/, '')}
                    </SyntaxHighlighter>
                  )
                },
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        )}

        {!loading && message.content && !isUser && (
          <div className="mt-1.5 flex justify-end">
            <button
              onClick={handleCopy}
              className="text-[10px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1 opacity-0 group-hover:opacity-100 transition"
            >
              {copied ? (
                <>
                  <Check className="h-3 w-3" /> Скопировано
                </>
              ) : (
                <>
                  <Copy className="h-3 w-3" /> Копировать
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {isUser && (
        <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center shrink-0 mt-0.5">
          <SquareUser className="h-4 w-4 text-muted-foreground" />
        </div>
      )}
    </motion.div>
  )
}
