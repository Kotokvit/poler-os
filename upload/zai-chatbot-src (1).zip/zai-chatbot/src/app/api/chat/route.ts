import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Сообщения приходят с клиента: [{role, content}, ...]
type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

const DEFAULT_SYSTEM_PROMPT =
  "Ты — полезный ассистент на русском языке. Отвечай ясно, по делу и используй Markdown для форматирования (списки, заголовки, блоки кода). Если пользователь пишет на другом языке — отвечай на том же языке.";

// Глобальный кэш инстанса ZAI, чтобы не пересоздавать на каждый запрос
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      messages,
      systemPrompt = DEFAULT_SYSTEM_PROMPT,
      thinking = false,
    } = body as {
      messages?: ChatMessage[];
      systemPrompt?: string;
      thinking?: boolean;
    };

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: "Поле messages обязательно и должно быть непустым массивом." },
        { status: 400 }
      );
    }

    // Валидируем роли
    const validRoles = new Set(["user", "assistant", "system"]);
    const sanitized: ChatMessage[] = messages
      .filter((m) => m && typeof m.content === "string")
      .filter((m) => validRoles.has(m.role))
      .map((m) => ({ role: m.role, content: m.content }));

    if (sanitized.length === 0) {
      return NextResponse.json(
        { error: "Не найдено валидных сообщений." },
        { status: 400 }
      );
    }

    // Системный промпт подаём как assistant-сообщение в начале,
    // как того требует спецификация z-ai-web-dev-sdk.
    const finalMessages: ChatMessage[] = [
      { role: "assistant", content: systemPrompt },
      ...sanitized,
    ];

    const zai = await getZAI();
    const completion = await zai.chat.completions.create({
      messages: finalMessages,
      thinking: { type: thinking ? "enabled" : "disabled" },
    });

    const content = completion.choices?.[0]?.message?.content ?? "";

    if (!content.trim()) {
      return NextResponse.json(
        { error: "Модель вернула пустой ответ. Попробуйте переформулировать." },
        { status: 502 }
      );
    }

    return NextResponse.json({
      success: true,
      content,
      usage: completion.usage ?? null,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[/api/chat] error:", message);
    return NextResponse.json(
      { error: "Внутренняя ошибка сервера.", detail: message },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: "/api/chat",
    method: "POST",
    description:
      "Прокси к Z.ai LLM через встроенный псевдо-API ключ окружения. Принимает { messages, systemPrompt?, thinking? } и возвращает { success, content, usage }.",
  });
}
