import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({
    object: "list",
    data: [
      { id: "glm-5", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-5.2", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-5.1", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-4.7", object: "model", created: 1719800000, owned_by: "zaibridge" },
    ],
  });
}
