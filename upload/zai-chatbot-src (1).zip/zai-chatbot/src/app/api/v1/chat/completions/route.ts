import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

/**
 * OpenAI-compatible Chat Completions endpoint.
 *
 * Этот маршрут принимает запросы в формате OpenAI Chat Completions и
 * исполняет их через встроенный псевдо-API ключ окружения (z-ai-web-dev-sdk).
 * Authorization header игнорируется — любой ключ принимается.
 *
 * Это позволяет подключать OpenClaw (или любой другой OpenAI-compatible клиент)
 * без необходимости в настоящем ZAI_API_KEY.
 *
 *   baseUrl для OpenClaw: http://127.0.0.1:3000/api/v1
 *   POST /api/v1/chat/completions  (stream и non-stream)
 *   GET  /api/v1/models
 */

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;
async function getZAI() {
  if (!zaiInstance) zaiInstance = await ZAI.create();
  return zaiInstance;
}

interface IncomingMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

function sseChunk(id: string, model: string, content: string, finish: string | null) {
  return (
    `data: ${JSON.stringify({
      id,
      object: "chat.completion.chunk",
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [{ index: 0, delta: content ? { content } : {}, finish_reason: finish }],
    })}\n\n`
  );
}

export async function POST(req: NextRequest) {
  let payload: any;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json(
      { error: { message: "Invalid JSON body" } },
      { status: 400 }
    );
  }

  const messages: IncomingMessage[] = Array.isArray(payload?.messages)
    ? payload.messages
    : [];
  if (messages.length === 0) {
    return NextResponse.json(
      { error: { message: "messages[] is required" } },
      { status: 400 }
    );
  }

  // Системный промпт подаём первым assistant-сообщением (требование SDK).
  let systemPrompt = "";
  const conv: IncomingMessage[] = [];
  for (const m of messages) {
    if (!m || typeof m.content !== "string") continue;
    if (m.role === "system" && !systemPrompt) systemPrompt = m.content;
    else if (m.role === "user" || m.role === "assistant") conv.push(m);
  }
  if (conv.length === 0) {
    return NextResponse.json(
      { error: { message: "no user/assistant messages" } },
      { status: 400 }
    );
  }

  const finalMessages: IncomingMessage[] = [];
  if (systemPrompt) finalMessages.push({ role: "assistant", content: systemPrompt });
  finalMessages.push(...conv);

  const model = String(payload.model || "glm-5").replace(/^zaibridge\//, "");
  const stream = !!payload.stream;
  const reasoningEffort = payload?.reasoning_effort;
  const thinking = !!reasoningEffort && reasoningEffort !== "off";

  try {
    const zai = await getZAI();
    const completion = await zai.chat.completions.create({
      messages: finalMessages,
      thinking: { type: thinking ? "enabled" : "disabled" },
    });
    const content = completion.choices?.[0]?.message?.content ?? "";

    const id = `chatcmpl-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const created = Math.floor(Date.now() / 1000);

    if (!stream) {
      return NextResponse.json({
        id,
        object: "chat.completion",
        created,
        model,
        choices: [
          {
            index: 0,
            message: { role: "assistant", content },
            finish_reason: "stop",
          },
        ],
        usage: completion.usage ?? {
          prompt_tokens: 0,
          completion_tokens: 0,
          total_tokens: 0,
        },
      });
    }

    // Streaming response
    const encoder = new TextEncoder();
    const stream_ = new ReadableStream({
      async start(controller) {
        controller.enqueue(encoder.encode(sseChunk(id, model, "", null)));
        const chunkSize = 3;
        for (let i = 0; i < content.length; i += chunkSize) {
          controller.enqueue(
            encoder.encode(
              sseChunk(id, model, content.slice(i, i + chunkSize), null)
            )
          );
        }
        controller.enqueue(encoder.encode(sseChunk(id, model, "", "stop")));
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      },
    });

    return new Response(stream_, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[/api/v1/chat/completions] error:", msg);
    return NextResponse.json(
      { error: { message: msg } },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    object: "list",
    data: [
      { id: "glm-5", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-5.2", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-5.1", object: "model", created: 1719800000, owned_by: "zaibridge" },
      { id: "glm-4.7", object: "model", created: 1719800000, owned_by: "zaibridge" },
    ],
  });
}
