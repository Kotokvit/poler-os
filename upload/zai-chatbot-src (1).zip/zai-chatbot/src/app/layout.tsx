import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Z.ai Чат-бот — подключение через встроенный API ключ",
  description:
    "Веб-чат на Next.js, который обращается к Z.ai LLM через встроенный псевдо-API ключ окружения. Без настройки — работает сразу.",
  keywords: ["Z.ai", "чат-бот", "Next.js", "LLM", "API ключ", "TypeScript"],
  authors: [{ name: "Z.ai" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Z.ai Чат-бот",
    description: "Веб-чат, подключённый к Z.ai через встроенный ключ окружения",
    url: "https://chat.z.ai",
    siteName: "Z.ai",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Z.ai Чат-бот",
    description: "Веб-чат, подключённый к Z.ai через встроенный ключ окружения",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
